package data_kantorpolisi;

public class Kasus {
    private String id;           // K1, K2...
    private String judul;        // Penipuan Online
    private String status;       // Terbuka/Proses/Ditutup
    private String penyidikNrp;  // NRP Polisi penanggung jawab

    public Kasus(String id, String judul, String penyidikNrp, String status) {
        this.id = id;
        this.judul = judul;
        this.penyidikNrp = penyidikNrp;
        this.status = status;
    }

    public String getId() { return id; }
    public String getJudul() { return judul; }
    public String getStatus() { return status; }
    public String getPenyidikNrp() { return penyidikNrp; }

    public void setJudul(String judul) { this.judul = judul; }
    public void setStatus(String status) { this.status = status; }
    public void setPenyidikNrp(String penyidikNrp) { this.penyidikNrp = penyidikNrp; }

    @Override
    public String toString() {
        return String.format("%s | %s | %s | %s", id, judul, status, penyidikNrp);
    }
}
