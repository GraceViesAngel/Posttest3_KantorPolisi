package data_kantorpolisi;

public class JadwalPatroli {
    private String id;        // J1, J2, ...
    private String tanggal;   // dd-MM-yyyy
    private String area;      // Terminal Kota, dst
    private String status;    // Dijadwalkan / Berlangsung / Telah Selesai
    private String nrp;       // NRP petugas yang dijadwalkan

    public JadwalPatroli(String id, String tanggal, String area, String status, String nrp) {
        this.id = id;
        this.tanggal = tanggal;
        this.area = area;
        this.status = status;
        this.nrp = nrp;
    }

    public String getId() { return id; }
    public String getTanggal() { return tanggal; }
    public String getArea() { return area; }
    public String getStatus() { return status; }
    public String getNrp() { return nrp; }

    public void setTanggal(String tanggal) { this.tanggal = tanggal; }
    public void setArea(String area) { this.area = area; }
    public void setStatus(String status) { this.status = status; }
    public void setNrp(String nrp) { this.nrp = nrp; }

    @Override
    public String toString() {
        return String.format("%s %s %s %s %s", id, tanggal, area, status, nrp);
    }
}
