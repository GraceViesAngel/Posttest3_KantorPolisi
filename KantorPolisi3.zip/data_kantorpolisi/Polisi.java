package data_kantorpolisi;

public class Polisi extends Personel {
    private String pangkat;
    private String status; // Aktif / Cuti

    public Polisi(String nrp, String nama, String pangkat, String status) {
        super(nrp, nama);
        this.pangkat = pangkat;
        this.status = status;
    }

    // Kompatibel dengan kode lama
    public String getNrp() { return getIdInternal(); }
    public void setNrp(String nrp) { setIdInternal(nrp); }

    public String getPangkat() { return pangkat; }
    public void setPangkat(String pangkat) { this.pangkat = pangkat; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String deskripsiTugas() {
        return "Menjaga keamanan, patroli, penegakan hukum, dan pelayanan masyarakat";
    }

    @Override
    public String toString() {
        return String.format("%s | %s | %s | %s", getNrp(), getNama(), pangkat, status);
    }
}
