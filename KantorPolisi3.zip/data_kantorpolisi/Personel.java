package data_kantorpolisi;

public class Personel {
    private String id;   // Untuk Polisi = NRP; untuk Staff = ID Staff
    private String nama;

    public Personel(String id, String nama) {
        this.id = id;
        this.nama = nama;
    }

    // ==== PUBLIC GETTER ID (PERBAIKAN UTAMA) ====
    public String getId() { return id; }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    // Tetap tersedia untuk subclass (Polisi/StaffSipil)
    protected String getIdInternal() { return id; }
    protected void setIdInternal(String id) { this.id = id; }

    public String deskripsiTugas() {
        return "Personel umum di Kantor Polisi";
    }
}

