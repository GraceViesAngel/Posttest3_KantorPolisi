package data_kantorpolisi;

public class StaffSipil extends Personel {
    private String bagian; // Administrasi/Keuangan/Umum, dll.
    private String status; // Aktif / Cuti

    public StaffSipil(String id, String nama, String bagian, String status) {
        super(id, nama);
        this.bagian = bagian;
        this.status = status;
    }

    // ==== PUBLIC GETTER/SETTER ID (PERBAIKAN UTAMA) ====
    public String getId() { return getIdInternal(); }
    public void setId(String id) { setIdInternal(id); }

    public String getBagian() { return bagian; }
    public void setBagian(String bagian) { this.bagian = bagian; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String deskripsiTugas() {
        return "Mendukung operasional kantor (administrasi, arsip, keuangan)";
    }

    @Override
    public String toString() {
        return String.format("%s %s %s %s", getId(), getNama(), bagian, status);
    }
}
