package menu_kantorpolisi;

import operasional_kantorpolisi.OperasionalKantorPolisi;
import data_kantorpolisi.Polisi;
import data_kantorpolisi.StaffSipil;
import data_kantorpolisi.JadwalPatroli;
import data_kantorpolisi.Kasus;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AplikasiKantorPolisi {

    private static final Scanner in = new Scanner(System.in);
    private static final int W = 75;

    // ====== Helper Tampilan ======
    private static String rep(char c, int n){
        StringBuilder s = new StringBuilder(n);
        for(int i=0;i<n;i++) s.append(c);
        return s.toString();
    }
    private static String pad(String s, int w){
        if(s==null) s="";
        if(s.length()>w) return s.substring(0,w);
        StringBuilder sb=new StringBuilder(s);
        while(sb.length()<w) sb.append(' ');
        return sb.toString();
    }
    private static String center(String s,int w){
        if(s.length()>=w) return s.substring(0,w);
        int l=(w-s.length())/2;
        int r=w-s.length()-l;
        return rep(' ',l)+s+rep(' ',r);
    }
    private static void garis(){
        System.out.println(".=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.=.");
    }
    private static void banner(String big,String sub){
        System.out.println(rep('*',W));
        System.out.println(center(big,W));
        System.out.println(rep('*',W));
        System.out.println(center(sub,W));
        System.out.println(rep('*',W));
        garis();
    }
    private static void judul(String t){
        garis();
        System.out.printf("| %s |\n", center(t.toUpperCase(), 69));
        garis();
    }
    private static void menuBox(String title, String... items){
        judul(title);
        for(String it: items) System.out.printf("| %-69s |\n", it);
        garis();
    }

    // ====== Tabel ======
    private static void tabelPolisi(List<Polisi> list){
        System.out.println();
        System.out.println(center("DAFTAR POLISI", W));
        System.out.println(rep('-',W));
        int wNrp=6,wNama=28,wPangkat=16,wStatus=12;
        System.out.printf("%s %s %s %s\n",
                pad("NRP",wNrp), pad("Nama",wNama), pad("Pangkat",wPangkat), pad("Status",wStatus));
        System.out.println(rep('-',W));
        if(list.isEmpty()) {
            System.out.println("(kosong)");
        } else {
            for(Polisi p: list) {
                System.out.printf("%s %s %s %s\n",
                        pad(p.getNrp(),wNrp), pad(p.getNama(),wNama), pad(p.getPangkat(),wPangkat), pad(p.getStatus(),wStatus));
            }
        }
        System.out.println(rep('-',W));
    }

    private static void tabelStaff(List<StaffSipil> list){
        System.out.println();
        System.out.println(center("DAFTAR STAFF SIPIL", W));
        System.out.println(rep('-',W));
        int wId=6,wNama=28,wBag=20,wStatus=12;
        System.out.printf("%s %s %s %s\n",
                pad("ID",wId), pad("Nama",wNama), pad("Bagian",wBag), pad("Status",wStatus));
        System.out.println(rep('-',W));
        if(list.isEmpty()) {
            System.out.println("(kosong)");
        } else {
            for(StaffSipil s: list) {
                System.out.printf("%s %s %s %s\n",
                        pad(s.getId(),wId), pad(s.getNama(),wNama), pad(s.getBagian(),wBag), pad(s.getStatus(),wStatus));
            }
        }
        System.out.println(rep('-',W));
    }

    private static void tabelJadwal(List<JadwalPatroli> list, OperasionalKantorPolisi svc){
        System.out.println();
        System.out.println(center("DAFTAR JADWAL", W));
        System.out.println(rep('-',W));
        int wId=6,wTgl=12,wArea=22,wNama=23,wSt=12;
        System.out.printf("%s %s %s %s %s\n",
                pad("ID",wId), pad("Tanggal",wTgl), pad("Area",wArea), pad("Nama Polisi",wNama), pad("Status",wSt));
        System.out.println(rep('-',W));
        if(list.isEmpty()) {
            System.out.println("(kosong)");
        } else {
            for(JadwalPatroli j: list){
                String nm = j.getNrp();
                Polisi p = svc.findPolisi(j.getNrp());
                if(p!=null) nm = p.getNama()+" ("+p.getPangkat()+")";
                System.out.printf("%s %s %s %s %s\n",
                        pad(j.getId(),wId), pad(j.getTanggal(),wTgl), pad(j.getArea(),wArea), pad(nm,wNama), pad(j.getStatus(),wSt));
            }
        }
        System.out.println(rep('-',W));
    }

    private static void tabelKasus(List<Kasus> list){
        System.out.println();
        System.out.println(center("DAFTAR KASUS", W));
        System.out.println(rep('-',W));
        int wId=6,wJud=36,wSt=12,wNrp=12;
        System.out.printf("%s %s %s %s\n",
                pad("ID",wId), pad("Judul",wJud), pad("Status",wSt), pad("Penyidik",wNrp));
        System.out.println(rep('-',W));
        if(list.isEmpty()) {
            System.out.println("(kosong)");
        } else {
            for(Kasus k: list) {
                System.out.printf("%s %s %s %s\n",
                        pad(k.getId(),wId), pad(k.getJudul(),wJud), pad(k.getStatus(),wSt), pad(k.getPenyidikNrp(),wNrp));
            }
        }
        System.out.println(rep('-',W));
    }

    // ====== Entry Point ======
    public static void main(String[] args) {
        OperasionalKantorPolisi svc = new OperasionalKantorPolisi();
        svc.seed(); // muat data contoh

        while(true){
            banner("KANTOR POLISI","SELAMAT DATANG DI SISTEM KANTOR POLISI");
            menuBox("MENU UTAMA",
                    "1. INFORMASI KANTOR POLISI",
                    "2. JADWAL PATROLI",
                    "3. KASUS PENYELIDIKAN",
                    "4. KELUAR");
            String m = tanya("Pilih");

            if(m.equals("1")) {
                menuInformasiKantorPolisi(svc);
            } else if(m.equals("2")) {
                menuJadwal(svc);
            } else if(m.equals("3")) {
                menuKasus(svc);
            } else if(m.equals("4")) {
                System.out.println("Selesai.");
                return;
            } else {
                System.out.println("Pilihan tidak dikenal.");
            }
        }
    }

    // ====== Menu Informasi Kantor (Polisi & Staff) ======
    private static void menuInformasiKantorPolisi(OperasionalKantorPolisi s){
        while(true){
            menuBox("INFORMASI KANTOR POLISI",
                    "1. POLISI",
                    "2. STAFF SIPIL",
                    "3. Kembali");
            String choose = tanya("Pilih");
            if (choose.equals("1")) {
                menuPolisi(s);
            } else if (choose.equals("2")) {
                menuStaff(s);
            } else if (choose.equals("3")) {
                return;
            } else {
                System.out.println("Pilihan tidak dikenal.");
            }
        }
    }

    // ====== Menu Polisi ======
    private static void menuPolisi(OperasionalKantorPolisi s){
        while(true){
            menuBox("FITUR INFORMASI POLISI",
                    "1. Tambah data polisi",
                    "2. Lihat Data",
                    "3. Detail Ringkasan (by NRP)",
                    "4. Ubah Data",
                    "5. Cari (nama/pangkat)",
                    "6. Hapus Data Polisi",
                    "7. Kembali");
            String m = tanya("Pilih");

            try{
                switch(m){
                    case "1":{
                        String nrp=tanya("NRP (3 angka & unik)");
                        String nama=tanya("Nama");
                        String pangkat=tanya("Pangkat");
                        String status=tanya("Status [Aktif/Cuti]");
                        s.tambahPolisi(new Polisi(nrp,nama,pangkat,status));
                        System.out.println("Berhasil ditambahkan.");
                        break;
                    }
                    case "2":{
                        tabelPolisi(s.semuaPolisi());
                        break;
                    }
                    case "3":{
                        String n=tanya("Masukkan NRP");
                        Polisi p=s.findPolisi(n);
                        if(p==null) System.out.println("NRP tidak ditemukan.");
                        else{
                            judul("Detail Ringkasan");
                            System.out.println("NRP    : "+p.getNrp());
                            System.out.println("Nama   : "+p.getNama());
                            System.out.println("Pangkat: "+p.getPangkat());
                            System.out.println("Status : "+p.getStatus());
                        }
                        break;
                    }
                    case "4":{
                        String n2=tanya("Masukkan NRP");
                        String nBaru=optional("Nama baru (kosong=skip)");
                        String pBaru=optional("Pangkat baru (kosong=skip)");
                        String sBaru=optional("Status baru [Aktif/Cuti] (kosong=skip)");
                        System.out.println(s.ubahPolisi(n2,nBaru,pBaru,sBaru)?"Diupdate.":"NRP tidak ditemukan.");
                        break;
                    }
                    case "5":{
                        String kw=tanya("Kata kunci (nama/pangkat)");
                        tabelPolisi(s.cariPolisi(kw));
                        break;
                    }
                    case "6":{
                        System.out.println(s.hapusPolisi(tanya("Masukkan NRP"))?"Dihapus.":"NRP tidak ditemukan.");
                        break;
                    }
                    case "7":{
                        return;
                    }
                    default:{
                        System.out.println("Pilihan tidak dikenal.");
                    }
                }
            }catch(IllegalArgumentException e){
                System.out.println("Input tidak valid: "+e.getMessage());
            }
        }
    }

    // ====== Menu Staff Sipil ======
    private static void menuStaff(OperasionalKantorPolisi s){
        while(true){
            menuBox("FITUR STAFF SIPIL",
                    "1. Tambah Staff",
                    "2. Lihat Data",
                    "3. Detail Ringkasan (by ID)",
                    "4. Ubah Data",
                    "5. Cari (nama/bagian)",
                    "6. Hapus Data Staff",
                    "7. Kembali");
            String m = tanya("Pilih");

            try{
                switch(m){
                    case "1":{
                        String id=tanya("ID Staff (3 angka & unik)");
                        String nama=tanya("Nama");
                        String bagian=tanya("Bagian (Administrasi/Keuangan/Umum/dll.)");
                        String status=tanya("Status [Aktif/Cuti]");
                        s.tambahStaff(new StaffSipil(id,nama,bagian,status));
                        System.out.println("Berhasil ditambahkan.");
                        break;
                    }
                    case "2":{
                        tabelStaff(s.semuaStaff());
                        break;
                    }
                    case "3":{
                        String id=tanya("Masukkan ID Staff");
                        StaffSipil st=s.findStaff(id);
                        if(st==null) System.out.println("ID Staff tidak ditemukan.");
                        else{
                            judul("Detail Ringkasan Staff");
                            System.out.println("ID     : "+st.getId());
                            System.out.println("Nama   : "+st.getNama());
                            System.out.println("Bagian : "+st.getBagian());
                            System.out.println("Status : "+st.getStatus());
                        }
                        break;
                    }
                    case "4":{
                        String id=tanya("Masukkan ID Staff");
                        String nBaru=optional("Nama baru (kosong=skip)");
                        String bBaru=optional("Bagian baru (kosong=skip)");
                        String sBaru=optional("Status baru [Aktif/Cuti] (kosong=skip)");
                        System.out.println(s.ubahStaff(id,nBaru,bBaru,sBaru)?"Diupdate.":"ID Staff tidak ditemukan.");
                        break;
                    }
                    case "5":{
                        String kw=tanya("Kata kunci (nama/bagian)");
                        tabelStaff(s.cariStaff(kw));
                        break;
                    }
                    case "6":{
                        System.out.println(s.hapusStaff(tanya("Masukkan ID Staff"))?"Dihapus.":"ID Staff tidak ditemukan.");
                        break;
                    }
                    case "7":{
                        return;
                    }
                    default:{
                        System.out.println("Pilihan tidak dikenal.");
                    }
                }
            }catch(IllegalArgumentException e){
                System.out.println("Input tidak valid: "+e.getMessage());
            }
        }
    }

    // ====== Menu Jadwal ======
    private static void menuJadwal(OperasionalKantorPolisi s){
        while(true){
            menuBox("JADWAL PATROLI",
                    "1. Buat Jadwal",
                    "2. Lihat Jadwal",
                    "3. Ubah Jadwal (Tanggal/Area) & Tandai Telah Selesai",
                    "4. Filter Area/Status",
                    "5. Hapus Jadwal",
                    "6. Kembali");
            String m = tanya("Pilih");

            try{
                switch(m){
                    case "1":{
                        String id=s.tambahJadwal(tanya("Tanggal"), tanya("Area"), tanya("NRP personel"));
                        System.out.println("Ditambahkan dengan ID: "+id);
                        break;
                    }
                    case "2":{
                        tabelJadwal(s.semuaJadwal(), s);
                        break;
                    }
                    case "3":{
                        String id3=tanya("ID Jadwal");
                        menuBox("Ubah Jadwal: "+id3,
                                "1) Ubah Tanggal   2) Ubah Area   3) Tandai Telah Selesai   4) Batal");
                        String pil=tanya("Pilih");
                        if(pil.equals("1")) {
                            System.out.println(s.ubahJadwalTanggal(id3,tanya("Tanggal baru"))?"-":"ID tidak ditemukan.");
                        } else if(pil.equals("2")) {
                            System.out.println(s.ubahJadwalArea(id3,tanya("Area baru"))?"-":"ID tidak ditemukan.");
                        } else if(pil.equals("3")) {
                            System.out.println(s.ubahJadwalStatus(id3,"Telah Selesai")?"-":"ID tidak ditemukan.");
                        }
                        break;
                    }
                    case "4":{
                        menuBox("FILTER JADWAL","1) Area   2) Status   3) Area + Status");
                        String f=tanya("Pilih");
                        if(f.equals("1")) {
                            tabelJadwal(s.filterJadwalArea(tanya("Area")), s);
                        } else if(f.equals("2")) {
                            tabelJadwal(s.filterJadwalStatus(tanya("Status (Dijadwalkan/Telah Selesai)")), s);
                        } else if(f.equals("3")){
                            String area=tanya("Area");
                            String st=tanya("Status (Dijadwalkan/Telah Selesai)");
                            List<JadwalPatroli> mix=new ArrayList<>();
                            for(JadwalPatroli j: s.semuaJadwal()){
                                if(j.getArea().equalsIgnoreCase(area) && j.getStatus().equalsIgnoreCase(st)) {
                                    mix.add(j);
                                }
                            }
                            tabelJadwal(mix, s);
                        }
                        break;
                    }
                    case "5":{
                        System.out.println(s.hapusJadwal(tanya("ID Jadwal"))?"Dihapus.":"ID tidak ditemukan.");
                        break;
                    }
                    case "6":{
                        return;
                    }
                    default:{
                        System.out.println("Pilihan tidak dikenal.");
                    }
                }
            }catch(IllegalArgumentException e){
                System.out.println("Input tidak valid: "+e.getMessage());
            }
        }
    }

    // ====== Menu Kasus ======
    private static void menuKasus(OperasionalKantorPolisi s){
        while(true){
            menuBox("KASUS PENYELIDIKAN",
                    "1. Tambah Kasus",
                    "2. Lihat Kasus (Filter Status)",
                    "3. Ubah Status (Baru/Proses/Ditutup)",
                    "4. Hapus Kasus",
                    "5. Kembali");
        String m = tanya("Pilih");

            try{
                switch(m){
                    case "1":{
                        String id=s.tambahKasus(tanya("Judul"), tanya("NRP Penyidik"));
                        System.out.println("Ditambahkan dengan ID: "+id);
                        break;
                    }
                    case "2":{
                        menuBox("LIHAT KASUS","1) Semua  2) Baru  3) Proses  4) Ditutup");
                        String pilih=tanya("Pilih");
                        if(pilih.equals("1")) {
                            tabelKasus(s.semuaKasus());
                        } else if(pilih.equals("2")) {
                            tabelKasus(s.kasusByStatus("Baru"));
                        } else if(pilih.equals("3")) {
                            tabelKasus(s.kasusByStatus("Proses"));
                        } else if(pilih.equals("4")) {
                            tabelKasus(s.kasusByStatus("Ditutup"));
                        }
                        break;
                    }
                    case "3":{
                        String id=tanya("ID Kasus");
                        String st=tanya("Status baru [Baru/Proses/Ditutup]");
                        System.out.println(s.ubahStatusKasus(id, st) ? "Diupdate." : "ID tidak ditemukan.");
                        break;
                    }
                    case "4":{
                        System.out.println(s.hapusKasus(tanya("ID Kasus")) ? "Dihapus." : "ID tidak ditemukan.");
                        break;
                    }
                    case "5":{
                        return;
                    }
                    default:{
                        System.out.println("Pilihan tidak dikenal.");
                    }
                }
            }catch(IllegalArgumentException e){
                System.out.println("Input tidak valid: "+e.getMessage());
            }
        }
    }

    // ====== Input Helpers ======
    private static String tanya(String label){
        System.out.print(label+": ");
        return in.nextLine().trim();
    }

    private static String optional(String label){
        System.out.print(label+": ");
        String s=in.nextLine().trim();
        return s.isEmpty()? null : s;
    }
}
